SELECT count(*)
FROM projects p left join projects pp on pp.id = p.parent_id